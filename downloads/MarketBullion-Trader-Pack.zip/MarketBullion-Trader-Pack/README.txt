MarketBullion Trader Pack
=========================
Thanks for buying The Trading Journal. Inside:

1. MarketBullion-Risk-Desk.xlsx  - position size and 1R/2R/3R risk calculator.
   Excel: just open it. Google Sheets: go to sheets.google.com > File > Import > Upload,
   or upload to Google Drive and open with Google Sheets. Type only into the gold boxes
   (cell locks don't carry over to Google Sheets, so take care not to overwrite formulas).
2. MarketBullion-My-Rules (A4 + US Letter)  - fillable PDF trading rules sheet.
3. MarketBullion-Pre-Market-Checklist (A4 + US Letter)  - fillable PDF checklist.
   Fill in with Adobe Acrobat Reader (free), Apple Files/Preview, or print them.
4. Wallpapers/  - 6 designs, phone and desktop, with and without text.

Trade the plan.
